public class Control {
    public static void main(String args[]){
        
        Stopwatch stopwatch = new Stopwatch();
    }
}



