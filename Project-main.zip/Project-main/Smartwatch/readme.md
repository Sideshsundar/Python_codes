# SIMPLE-JAVA-WATCH-
This is a SIMPLE SOFTWARE BASED WATCH built with JAVA language with added features like DATE, DAY, STOPWATCH and ALARM.

In these files, the file MAIN.java is the Main file which has to be executed. It's the Main or control file of FRAME.java.

FRAME.java contains the code for TIME, DATE and DAY. It also includes buttons to invoke the STOPWATCH and ALARM.

TEXTBOX.java is the file which contains the code for ALARM. The Main or executable file to run TEXTBOX.java seperately is TEXTBOXCONTROL.java.

STOPWATCH.java is the file which contains the code for STOPWATCH. The Main or executable file to run STOPWATCH.java seperately is CONTROL.java.

Alarm-Ringtone.wav is the alarm tone used for the ringing functionality in Alarm. Make sure that the Alarm-Ringtone.wav file is in the same folder of your project where all the other code files are present. The path location of the code files and Alarm-Ringtone.wav has to be same.