import java.io.IOException;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import javax.sound.sampled.*;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

public class textboxcontrol {
    public static void main(String args[])throws LineUnavailableException, UnsupportedAudioFileException, IOException {
        new textbox();
        
            
            
        
    }    
    
    
}