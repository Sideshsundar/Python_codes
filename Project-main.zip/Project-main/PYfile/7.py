#7
#printing using print() function
a=33
b=44
print(a+b)

#without adding seperator method to the print function
print("group","11")

#using seperator method to the print function
print("group","11",sep = ",")

#Printing the function witout the end method
a=33
b=44
print(a)
print(b)

#We can use the end method to print the function
a=33
b=44
print(a,end=",")
print(b)

#now we will use format method
a = 33
b = 44
print("The two numbers are {0} and {1}".format(a,b))
