#13
N = int(input("Enter the N th number: "))
print("Squares of first N natural numbers are: ")
for i in range(1,N+1):
    print(i*i)
