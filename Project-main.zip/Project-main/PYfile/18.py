#18
def func(a,b):
    if(a>b):
        print("Product ",a*b)
    elif(a<b):
        print("Modulus ",a%b)

n1 = int(input("Enter a number: "))
n2 = int(input("Enter a number: "))
func(n1,n2)
