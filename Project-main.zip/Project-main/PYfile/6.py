#6
str = input("Enter a string: \n")
print("The entered string is: ",str)
