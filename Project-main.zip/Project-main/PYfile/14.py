#14
print("Natural numbers less than 100 are: ")
for i in range(1,100):
    print(i,end = " , ")
