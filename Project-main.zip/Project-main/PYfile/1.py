def func(a,b):
    prod = a*b
    square = prod*prod
    
    print("Product of entered numbers is ",prod)
    print("Product of their squares is ",square)

n1 = int(input("Enter a number: "))
n2 = int(input("Enter a number: "))
func(n1,n2)
