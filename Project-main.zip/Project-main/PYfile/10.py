#10
t1 = (1,2,1,2)
print(t1.index(2))
print(t1.count(2))
t2 = ((1,2),(3,4),(5,6))
print(t2.index((5,6)))
print(t2.count((3,4)))