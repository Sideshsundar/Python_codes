#3
s1 = 'Shyam'
s2 = 'Ganesh'
s = s1+s2
print(s)
print("Last five characters ",s[:len(s)-6:-1])
