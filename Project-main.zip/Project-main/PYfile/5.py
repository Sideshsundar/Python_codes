#5
str = 'Chennai'
print(str.upper())
print(str.lower())
print(str.split())
