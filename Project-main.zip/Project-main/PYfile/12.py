#12
n1 = int(input("Enter first number: "))
n2 = int(input("Enter second number: "))
if n1>n2:
    print(n1," is the greatest of entered numbers")
elif n1<n2:
    print(n2," is the greatest of entered numbers")
elif n1==n2:
    print(n1," == ",n2)
