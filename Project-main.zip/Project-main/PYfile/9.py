#9
dic={"Sai teja":21124,"Shabarinath":21141,"Shyam":21149,"Sidesh":21150, "Jayakrishna":21154,}
print("Printing dictionary: ")
print(dic)
print()
print("Printing value of second key: ",dic["Shyam"])
print()
# b
print("Keys() - ",dic.keys())
print()
print("values() - ",dic.values())
print()
print("items() - ",dic.items())
print()
