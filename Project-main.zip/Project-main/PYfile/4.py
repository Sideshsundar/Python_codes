#4
print("S"*5)